package com.bob.sign_in;

import android.os.Environment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class ZYZSignIn {


	SignActivity activity;
	public ZYZSignIn(SignActivity activity) {
		this.activity=activity;
	}

	// 发送请求HTTP-POST请求 url:请求地址; entity:json格式请求参数
	public static String httppost(String url, String data, InputStream requestFile, String token) {
		try {
			HttpClient httpClient = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(url);
			setHttpPost(requestFile, httpPost);
			httpPost.addHeader("token", token);
			StringEntity se = new StringEntity(data, "UTF-8");
			se.setContentType("text/plain");
			httpPost.setEntity(se);

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity1 = response.getEntity();
//			String resStr = null;
//			if (entity1 != null) {
//				resStr = EntityUtils.toString(entity1, "UTF-8");
//			}
//			httpClient.close();
//			response.close();
			return getResponseString(entity1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	// 发送请求HTTP-POST请求 url:请求地址; entity:json格式请求参数
	public static String httppost(String url, String data, InputStream requestFile) {
		try {
			HttpClient httpClient = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(url);
			setHttpPost(requestFile, httpPost);
			StringEntity se = new StringEntity(data);
			se.setContentType("text/plain");
			httpPost.setEntity(se);

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity1 = response.getEntity();
//			InputStream is = response.getEntity().getContent();
			//GZIPInputStream
//			String resStr = null;
//			if (entity1 != null) {
//				resStr = EntityUtils.toString(entity1, "UTF-8");
//			}
//			resStr=uncompress(resStr.getBytes());
			return getResponseString(entity1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	//Content-Encoding: gzip
	static String getResponseString(HttpEntity entity){
		try {
			if ((entity.getContentEncoding() != null)
					&& entity.getContentEncoding().getValue().contains("gzip")) {
				GZIPInputStream gzip = new GZIPInputStream(
						new ByteArrayInputStream(EntityUtils.toByteArray(entity)));
				InputStreamReader isr = new InputStreamReader(gzip);
				BufferedReader br = new BufferedReader(isr);
				StringBuilder sb = new StringBuilder();
				String temp;
				while((temp = br.readLine()) != null){
					sb.append(temp);
					sb.append("\r\n");
				}
				isr.close();
				gzip.close();

				return sb.toString();
			} else {
				return EntityUtils.toString(entity);
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void setHttpPost(InputStream file, HttpPost httpsConn) {
		try {
			InputStreamReader inputReader = new InputStreamReader(file);
			BufferedReader bf = new BufferedReader(inputReader);
			// 按行读取字符串
			String str;

			while ((str = bf.readLine()) != null) {
				if (str.startsWith(":"))
					continue;
				if (str.trim().equals(""))
					break;
				String[] strs = str.split(":");
				httpsConn.addHeader(strs[0].trim(), strs[1].trim());
			}
			bf.close();
			inputReader.close();
//				return httpsConn;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//    	return null;
	}


	private String token;
	private String userId;
	private static String activityid=null;

	public boolean login(String username, int last) throws IOException {
		if (login(username, username.substring(username.length() - last, username.length())))
			return true;
		return false;
	}

	public boolean login(String username) throws IOException {
//		System.out.println(username.substring(username.length()-4,username.length()));
		if (login(username, username.substring(username.length() - 4, username.length())))
			return true;
//		System.out.println(username.substring(username.length()-6,username.length()));
		if (login(username, username.substring(username.length() - 6, username.length())))
			return true;
//		System.out.println(username.substring(username.length()-8,username.length()));
		if (login(username, username.substring(username.length() - 8, username.length())))
			return true;
		return false;
	}

	public boolean login(String username, String password) throws IOException {
		String uri = "https://yzbanktime.zyh365.com/common/api-public";
		String output = ZYZSignIn.httppost(uri, "api=userCenter%2Flogin&username=" + username + "&password=" + password,
				activity.getAssets().open("zyz/login1.txt"));
		output.replace(" ", "");
		System.out.println(output);
		String errCode = output.split("\"errCode\":\"")[1].trim();
		errCode = errCode.substring(0, 4);
		if (!"0000".equals(errCode))
			return false;
		String token = output.split("\"token\":\"")[1].trim();
		token = token.substring(0, token.length() - 2);
//		System.out.println(token);

		String output2 = ZYZSignIn.httppost(uri, "api=login%2Ftoken%2FloginInfoByShareToken",
				activity.getAssets().open("zyz/login2.txt"), token);
		output2.replace(" ", "");
		System.out.println(output2);
		userId = output2.split("\"userId\":\"")[1].trim();
		userId = userId.substring(0, userId.length() - 2);
//		System.out.println(getActivityId("561951"));

//		getActivityId("561951");

//		activityid = "16260512411697ac6ebd4cc914a408f79c8044c9de9a8";

//		String output3 = ZYZSignIn.httppost(uri, "api=activity%2FhoursList&page=1&rows=1&year=2021&zyzid="+userId,
//				new File("zyz/login3.txt"));
//		output3.replace(" ", "");
////		System.out.println(output3);
//		activityid = output3.split("\"activityid\":\"")[1].trim();
//		activityid = activityid.split("\",")[0];
//		
//		System.out.println(activityid);
		return true;

	}

	public boolean is_sign() throws IOException {
		String issignurl = "https://appapi.zyh365.com/card-activity/is-sign?app_id=h5";
		String output_is_sign = ZYZSignIn.httppost(issignurl, "zyzid=" + userId + "&mobile_unique=" + userId,
				activity.getAssets().open("zyz/is-sign.txt"));
		System.out.println(output_is_sign);
		String is_sign = output_is_sign.split("\"isface\":")[1].trim();
//		System.out.println(is_sign);
//		is_sign = is_sign.split("},")[0];
//		System.out.println(is_sign);
		// 已经签到
		if (is_sign.startsWith("0"))
			return true;
		else// 已经签退
			return false;
	}

	public String setActivityId(String code) throws IOException {
		if(activityid!=null)return activityid;

		BufferedWriter outCur = new BufferedWriter(new FileWriter(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Download/current.code"));
//		outCur.write(code);
//		outCur.close();

		File ff = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Download/"+code+".txt");
		if(ff.exists()) {
			BufferedReader bf = new BufferedReader(new FileReader(new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/" + code + ".txt")));
			// 按行读取字符串
			String str;
			if ((str = bf.readLine()) != null) {
				activityid = str.trim();
				outCur.write(code+"="+activityid);
				outCur.close();
				return activityid;
			}
		}

		String detailurl = "https://appapi.zyh365.com/card-activity/detail?app_id=h5";
		String output_detail = ZYZSignIn.httppost(detailurl, "zyzid=" + userId + "&mobile_unique=" + userId+"&activity_code="+code,
				activity.getAssets().open("zyz/detail.txt"));
//		System.out.println(output_detail);
		output_detail.replace(" ", "");
		String activitycode = output_detail.split("\"card_activityid\":\"")[1].trim();
		activityid=activitycode.split("\"")[0];

		BufferedWriter out = new BufferedWriter(new FileWriter(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Download/"+code+".txt"));
		out.write(activityid);
		out.close();

		outCur.write(code+"="+activityid);
		outCur.close();
		return activityid;
	}

	public boolean sign_in() throws IOException {

		String signurl = "https://appapi.zyh365.com/card-activity/sign?app_id=h5";
		String output4 = ZYZSignIn.httppost(signurl,
				"card_activityid=" + activityid + "&zyzid=" + userId + "&mobile_unique=" + userId
						+ "&sign_type=1&earth_lng=121.62872037694473&earth_lat=29.87789849393705&isface=0&token="
						+ token,
				activity.getAssets().open("zyz/sign1.txt"));
		System.out.println(output4);
		String errCode = output4.split("\"errCode\":\"")[1].trim();
		errCode = errCode.substring(0, 4);
		if (!"0000".equals(errCode))
			return false;
		return true;
	}

	public boolean sign_out() throws IOException {

		String signurl = "https://appapi.zyh365.com/card-activity/sign?app_id=h5";
		String output4 = ZYZSignIn.httppost(signurl,
				"card_activityid=" + activityid + "&zyzid=" + userId + "&mobile_unique=" + userId
						+ "&sign_type=2&earth_lng=121.62872037694473&earth_lat=29.87789849393705&isface=0&token="
						+ token,
				activity.getAssets().open("zyz/sign2.txt"));
		System.out.println(output4);
		String errCode = output4.split("\"errCode\":\"")[1].trim();
		errCode = errCode.substring(0, 4);
		if (!"0000".equals(errCode))
			return false;
		return true;
	}
}