package com.bob.sign_in;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class SignActivity extends AppCompatActivity {

    TextView textView;
    Vibrator mVibrator;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if(msg.obj==null) return;
            Log.e("obj",msg.obj+"");
            String pstr= textView.getText().toString();
            textView.setText(msg.obj+pstr);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);
        textView = (TextView) findViewById(R.id.textView);
        textView.setMovementMethod(ScrollingMovementMethod.getInstance());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        //获取手机震动服务
        mVibrator=(Vibrator)getApplication().getSystemService(Service.VIBRATOR_SERVICE);

        Intent intent=this.getIntent();
        Bundle bundle=intent.getExtras();
        String code=bundle.getString("code");
        System.out.println("code:"+code);
        int number=bundle.getInt("number");
        System.out.println("number:"+number);
        new Thread(new Runnable() {
            int i = 0;
            int noPasswordNum = 0;
            int successNum = 0;
            int failed = 0;
            int  num = number;
            @Override
            public void run() {
                Random rd = new Random();
                try {
                    textView = (TextView) findViewById(R.id.textView);
                    Message notifyMsg;
                    notifyMsg = handler.obtainMessage(1, 60, 100, "随机选取的" + num + "人签到\n");
                    handler.sendMessage(notifyMsg);

                    final Excel excel = new Excel();
                    excel.readExcel(getAssets().open("names.xlsx"));
                    excel.random(num);
                    notifyMsg = handler.obtainMessage(1, 60, 100, excel.nameslist + "\n");
                    handler.sendMessage(notifyMsg);
                    // 按行读取字符串
                    for (; i < excel.nameslist.size(); i++) {
                        Thread.sleep(rd.nextInt(10) * 1000);
                        ZYZSignIn zyz = new ZYZSignIn(SignActivity.this);
                        if (excel.passwordlist.get(i).contains("null")) {
                            noPasswordNum++;
                            continue;
                        }
                        if (zyz.login(excel.idlist.get(i), excel.passwordlist.get(i))) {
                            notifyMsg = handler.obtainMessage(1, 60, 100, "第"+(i+1) + "个:" + excel.nameslist.get(i) + "(" + excel.idlist.get(i) + ":" + excel.passwordlist.get(i) + ")登陆成功！\n");
                            zyz.setActivityId(code);
                            handler.sendMessage(notifyMsg);
                        } else {
                            failed++;
                            notifyMsg = handler.obtainMessage(1, 60, 100, "第"+(i+1) + "个:" + excel.nameslist.get(i) + "(" + excel.idlist.get(i) + ":" + excel.passwordlist.get(i) + ")登陆失败！\n");
                            handler.sendMessage(notifyMsg);
                            continue;
                        }
                        if (zyz.is_sign()) {
                            notifyMsg = handler.obtainMessage(1, 60, 100, "第"+(i+1) + "个:" + excel.nameslist.get(i) + "(" + excel.idlist.get(i) + ":" + excel.passwordlist.get(i) + ")已经签到，前先签退！\n");
                            handler.sendMessage(notifyMsg);
                            continue;
                        }
                        if (zyz.sign_in()) {
                            notifyMsg = handler.obtainMessage(1, 60, 100, "第"+(i+1) + "个:" + excel.nameslist.get(i) + "(" + excel.idlist.get(i) + ":"+excel.passwordlist.get(i)+")签到成功！\n");
                            handler.sendMessage(notifyMsg);
                            successNum++;
                        } else {
                            failed++;
                            System.out.println("i1i1i222=="+i);
                            notifyMsg = handler.obtainMessage(1, 60, 100, "第"+(i+1) + "个:" + excel.nameslist.get(i) + "(" + excel.idlist.get(i) + ":"+excel.passwordlist.get(i)+")签到失败！\n");
                            handler.sendMessage(notifyMsg);
                        }
                    }//for
                    notifyMsg = handler.obtainMessage(1, 60, 100,
                            "总人数：" + excel.nameslist.size() + "\n"
                                    +"密码未知人数：" + noPasswordNum + "\n"
                                    +"签到成功总人数：" + successNum + "\n"
                                    +"登陆失败和签到失败总人数：" + failed + "\n");
                    handler.sendMessage(notifyMsg);
                    if(successNum>0){
                        //写入到文件
                        Date now = new Date();
                        SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日");
                        BufferedWriter out = new BufferedWriter(new FileWriter(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Download/"+f.format(now)+".txt"));
                        f = new SimpleDateFormat("kk:mm");
                        out.write(f.format(now));
                        out.close();
                    }
                    mVibrator.vibrate(new long[]{100,1000,100,1000,100,1000,100,1000},-1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    public static int number(InputStream numberfile) {
        InputStreamReader inputReader;
        try {
            inputReader = new InputStreamReader(numberfile);
            BufferedReader bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            int i=0;
            while ((str = bf.readLine()) != null) {
                int nn = Integer.parseInt(str.trim());
                return nn;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return 50;
    }
}