package com.bob.sign_in;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button=(Button)findViewById(R.id.button);
        EditText peopleNum = (EditText)findViewById(R.id.editTextTextPersonNumber);
        EditText code = (EditText)findViewById(R.id.editTextTextCode);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent();
                intent.setClass(MainActivity.this,SignActivity.class);
                //利用bundle来存取数据
                Bundle bundle=new Bundle();
                if(peopleNum.getText().toString().startsWith("默认")){
                    String ss[]=peopleNum.getText().toString().split(":");
                    if(ss.length>=2)
                        bundle.putInt("number",Integer.parseInt(ss[1]));
                    else
                        bundle.putInt("number",55);
                }else{
                    bundle.putInt("number",Integer.parseInt(peopleNum.getText().toString()));
                }

                if(code.getText().toString().startsWith("默认")){
                    String ss[]=code.getText().toString().split(":");
                    if(ss.length>=2)
                        bundle.putString("code",ss[1]);
                    else
                        bundle.putString("code","751567");
                }else{
                    bundle.putString("code",code.getText().toString());
                }
                //再把bundle中的数据传给intent，以传输过去
                intent.putExtras(bundle);
                startActivityForResult(intent,0);
            }
        });
    }
}