package com.bob.sign_out;

import android.os.Environment;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class Excel {

	public List<String> nameslist= new ArrayList<String>();
	public List<String> idlist= new ArrayList<String>();
	public List<String> passwordlist= new ArrayList<String>();
	public void random(int num) {
		List<String> nl= new ArrayList<String>();
		List<String> il= new ArrayList<String>();
		List<String> pl= new ArrayList<String>();
		Random rd =  new Random();
		int total=0;
		while(true) {
			int nn=rd.nextInt(nameslist.size());
			if(nl.contains(nameslist.get(nn))) continue;
			if(passwordlist.get(nn).contains("null")) continue;
			nl.add(nameslist.get(nn));
			il.add(idlist.get(nn));
			pl.add(passwordlist.get(nn));
			if(nl.size()==num) break;
		}
		nameslist=nl;
		idlist=il;
		passwordlist=pl;
		try {
			writeExecl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void readExcel(File fn) throws Exception {
		readExcel(new FileInputStream(fn));
	}
	public void readExcel(InputStream inputStream) throws Exception {
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.getSheetAt(0);
	    int rowNums = sheet.getPhysicalNumberOfRows();
	    for (int rowNum = 1; rowNum < rowNums; rowNum++) {
	        Row row = sheet.getRow(rowNum);
	        if(row != null){
	            int count = row.getPhysicalNumberOfCells();
	            for (int cellNum = 1; cellNum < count; cellNum++) {
	                Cell cell = row.getCell(cellNum);
	                if(cell != null){
	                    int cellType = cell.getCellType();
	                    String cellValue = "";
	                    switch (cellType){
	                        case HSSFCell.CELL_TYPE_STRING:
	                            cellValue = cell.getStringCellValue();
	                            break;
	                        case HSSFCell.CELL_TYPE_BOOLEAN:
	                            cellValue = String.valueOf(cell.getBooleanCellValue());
	                            break;
	                        case HSSFCell.CELL_TYPE_BLANK:
	                            break;
	                        case HSSFCell.CELL_TYPE_ERROR:
	                            break;
	                    }
	                    if(cellNum==1) {
	                    	nameslist.add(cellValue.trim());
	                    }else if(cellNum==2) {
	                    	idlist.add(cellValue);
	                    }else if(cellNum==3) {
	                    	passwordlist.add(cellValue.substring(1,cellValue.length()).trim());
	                    }
	                }
	            }
	        }
	    }
	    inputStream.close();
	}

	  public void writeExecl() throws  Exception{
	        //创建Workbook工作簿
	        Workbook w = new XSSFWorkbook();
	        //创建Sheet
	        Sheet sheet = w.createSheet("Excel统计表");
	        Row header = sheet.createRow(0);
	        //创建列
	        Cell title = header.createCell(0);
	        title.setCellValue("序号");
	        title = header.createCell(1);
	        title.setCellValue("姓名");
	        title = header.createCell(2);
	        title.setCellValue("身份证");
	        title = header.createCell(3);
	        title.setCellValue("密码");
	        for(int i=0;i<nameslist.size();i++) {
		        //创建行
		        Row row = sheet.createRow(i+1);
		        //创建列
		        Cell cell = row.createCell(0);
		        cell.setCellValue(i+1);
		        cell = row.createCell(1);
		        cell.setCellValue(nameslist.get(i));
		        cell = row.createCell(2);
		        cell.setCellValue(idlist.get(i));
		        cell = row.createCell(3);
		        cell.setCellValue("#"+passwordlist.get(i));
	        }
	        Date now = new Date(); 
	        SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日");

	        //写入到文件
	        FileOutputStream fo = new FileOutputStream(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Download/"+f.format(now)+".xlsx");
	        w.write(fo);
	        fo.close();
	    }
	public static void main(String[] args) throws Exception {
//		Excel excel =new Excel();
//		excel.readExcel("zyz/names.xlsx");
//		excel.random(50);
//		excel.writeExecl();
//		System.out.println(excel.nameslist);
//		System.out.println(excel.idlist);
//		System.out.println(excel.passwordlist);
	}
}
