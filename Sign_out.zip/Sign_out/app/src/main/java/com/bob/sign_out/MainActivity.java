package com.bob.sign_out;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button=(Button)findViewById(R.id.button);
        TextView textView=(TextView)findViewById(R.id.textView2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent();
                intent.setClass(MainActivity.this,SignActivity.class);
                //利用bundle来存取数据

                startActivityForResult(intent,0);
            }
        });
        Date now = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日");
        String onlinetime=during(new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Download/"+f.format(now)+".txt"));
        textView.append("\n"+onlinetime);
    }
    public static String during(File numberfile) {
        try {
            BufferedReader bf = new BufferedReader(new FileReader(numberfile));
            // 按行读取字符串
            String str;
            int i=0;

            Date now = new Date();
            SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日");
            int hour = now.getHours();
            int min=now.getMinutes();
            int during=0;
            if ((str = bf.readLine()) != null) {
                String sss[]=str.split(":");
                if(sss.length==2){
                    int thour=Integer.parseInt(sss[0]);
                    int tmin=Integer.parseInt(sss[1]);
                    during=hour*60+min-thour*60-tmin;
                    return "\t"+during/60+"小时"+during%60+"分钟";
                }else{
                    return "";
                }
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }
}