package com.example.maotaiwechatalarm;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class MainActivity extends AppCompatActivity {

    public static String starttime="";
    TextView textView;
    boolean stopRequest=false;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            textView.setText(msg.obj+"");
        }
    };
    Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
    Ringtone r = RingtoneManager.getRingtone(MainActivity.this, notification);
    //创建震动服务对象
    private Vibrator mVibrator;
    Button button;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_main);

        //获取手机震动服务
        mVibrator=(Vibrator)getApplication().getSystemService(Service.VIBRATOR_SERVICE);

        textView = (TextView) findViewById(R.id.textView);
        button =(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!stopRequest) {//先停止其他线程
                    stopRequest=true;
                    button.setText("开始发送请求");
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }else {
                    sendRequest();
                    button.setText("停止发送请求");
                }
            }
        });
        starttime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String clip= getClipboardContent(getBaseContext());
        TextView textViewClip = (TextView) findViewById(R.id.textViewClip);
        textViewClip.setText(clip);
        String[] strs=clip.split("\n");
        boolean isall=false;
        for(String str:strs){
            if(str.startsWith("User-Agent")){
                HttpsUtil.User_Agent=str.split(":")[1].trim();
                isall=true;
            }
            if(str.startsWith("Cookie")){
                HttpsUtil.Cookie=str.split(":")[1].trim();
                isall=true;
            }
        }
        if(!isall) if (clip.startsWith("lambo-sso-key")) {
            HttpsUtil.Cookie = clip.trim();
        }

        Button buttonClip =(Button)findViewById(R.id.buttonClip);
        buttonClip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //取消震动
                mVibrator.cancel();
                r.stop();
            }
        });
        sendRequest();

    }


    /**
     * 获取剪切板上的内容
     */
    @Nullable
    public static String getClipboardContent(Context context) {
        ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            ClipData data = cm.getPrimaryClip();
            if (data != null && data.getItemCount() > 0) {
                ClipData.Item item = data.getItemAt(0);
                if (item != null) {
                    CharSequence sequence = item.coerceToText(context);
                    if (sequence != null) {
                        return sequence.toString();
                    }
                }
            }
        }
        return null;
    }

    public void sendRequest(){
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                for (; ; ){
                    try {
                        String uri = "https://reserve.moutai.com.cn/api/rsv-server/anon/consumer/getShops";
                        byte[] bytes = HttpsUtil.doPost(uri, "custId=******");
                        String output = new String(bytes);
                        String timeStr1 = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                        handler.sendEmptyMessage(1);
                        Message notifyMsg;
                        notifyMsg = handler.obtainMessage(1, 60, 100, starttime+"==>"+timeStr1+"\n"+output + "\n");
                        handler.sendMessage(notifyMsg);
                        Thread.sleep(2000);
                        if(output.contains("浙江")) {
                            //设置震动周期，数组表示时间：等待+执行，单位是毫秒，下面操作代表:等待100，执行1000，等待100，执行1000，
                            //后面的数字如果为-1代表不重复，之执行一次，其他代表会重复，0代表从数组的第0个位置开始
                            mVibrator.vibrate(new long[]{100,1000,100,1000},0);
                            notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                            r = RingtoneManager.getRingtone(MainActivity.this, notification);
                            r.play();
                            break;
                        }
                        if(output.contains("请通过微信官方客户端查看")) {
                            mVibrator.vibrate(new long[]{100,100,100,100},0);
                            notification = RingtoneManager.getDefaultUri(6);
                            r = RingtoneManager.getRingtone(MainActivity.this, notification);
                            r.play();
                            break;
                        }
                        if(stopRequest){
                            break;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                stopRequest=false;
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        button.setText("开始发送请求");
                    }
                });

            }
        }).start();
    }
}